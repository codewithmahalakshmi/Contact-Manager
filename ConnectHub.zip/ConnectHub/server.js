import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

// Temporary contact storage
let contacts = [];

/* ---------------- HOME ---------------- */

app.get("/", (req, res) => {
  res.send("Contact Manager Server Running ");
});

/* ---------------- ADD CONTACT ---------------- */

app.post("/contacts", (req, res) => {

  const { name, phone, email } = req.body;

  if (!name || !phone || !email) {
    return res.status(400).json({
      message: "All fields are required"
    });
  }

  const newContact = {
    id: Date.now(),
    name,
    phone,
    email
  };

  contacts.push(newContact);

  res.json({
    message: "Contact added successfully",
    contact: newContact
  });

});

/* ---------------- GET ALL CONTACTS ---------------- */

app.get("/contacts", (req, res) => {

  res.json({
    message: "All contacts",
    contacts: contacts
  });

});

/* ---------------- DELETE CONTACT ---------------- */

app.delete("/contacts/:id", (req, res) => {

  const id = parseInt(req.params.id);

  contacts = contacts.filter(contact => contact.id !== id);

  res.json({
    message: "Contact deleted successfully"
  });

});

/* ---------------- UPDATE CONTACT ---------------- */

app.put("/contacts/:id", (req, res) => {

  const id = parseInt(req.params.id);
  const { name, phone, email } = req.body;

  const contact = contacts.find(c => c.id === id);

  if (!contact) {
    return res.status(404).json({
      message: "Contact not found"
    });
  }

  contact.name = name || contact.name;
  contact.phone = phone || contact.phone;
  contact.email = email || contact.email;

  res.json({
    message: "Contact updated successfully",
    contact
  });

});

/* ---------------- SERVER START ---------------- */

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});